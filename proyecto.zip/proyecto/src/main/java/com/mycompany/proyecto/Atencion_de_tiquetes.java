package com.mycompany.proyecto;

public class Atencion_de_tiquetes {
    
}

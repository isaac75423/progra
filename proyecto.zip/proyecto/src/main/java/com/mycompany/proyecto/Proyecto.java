package com.mycompany.proyecto;

import javax.swing.JOptionPane;

public class Proyecto {

    public static void main(String[] args) {
        String menu = """
                      1. CREACION DE TICKETS
                      2. ATENCION DE TICKETS
                      3. LLENADO DE COLAS 
                      4. ATENCION DE TICKETS
                      5. REPORTES
                      6. Salir""";
        String opcion;
        do {
            opcion = JOptionPane.showInputDialog(menu);  
            if (opcion == null) {
                break;
            }
            switch (opcion) {
                case "1":
                    JOptionPane.showMessageDialog(null, "___CREACION DE TICKETS___");
                   
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "___ATENCION DE TICKETS___");

                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "___LLENADO DE COLAS___");

                    break;
                case "4":
                    JOptionPane.showMessageDialog(null, "___ATENCION DE TICKETS___");

                    break;
                case "5":
                    JOptionPane.showMessageDialog(null, "___REPORTES___");

                    break;
                case "6":
                    JOptionPane.showMessageDialog(null, "___Saliendo___");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Inténtalo de nuevo.");
                    break;
            }
        } while (!opcion.equals("6"));
    }
}
